#define CONSOLE_DEBUG 0

#define SW_VERSION 2.7

#define UDP_READ_TRIALS 50000
//-------------------------------------
#define REG_APPSEL 0
#define REG_AUTH   0x01
#define REG_FW_VERS 2
#define REG_HW_VERS 3			
#define REG_OP_HRS 5
#define REG_UPTIME 7
#define REG_FLAGS  9


#define REG_PWM_FREQ		0x10
#define REG_INTERLOCK_DELAY 0x12
#define REG_PWM_DUTYCYCLE   0x13

#define REG_LEG_HL          0x14
#define REG_LEG_EN          0x15
#define	REG_AUX_CTRL		0x16
#define	REG_TRIG_MASK		0x17
#define	REG_AUX_TEST		0x0D
#define	REG_CURLIMIT_TOT 	0x19
#define	REG_CURLIMIT_LEG	0x18
#define	REG_VOLTLIMIT  		0x1A
#define	REG_ADC_TESTDATA	0x1B
#define	REG_HOUSEKEEPING	0x1C
#define REG_FLT_STAT 		0x20			
#define REG_LEG_EN_RB 		0x21			
#define REG_FLT_STAT_REG	0x22			
#define REG_LEG_EN_RB_REG	0x23			
#define REG_CURLIMIT_STAT	0x24			
#define REG_RINGSTAT		0x25			

#define	REG_APPTEST_CTRL	0x1C

#define REG_CAN_SCHED       0x1D
#define REG_CAN_CYCLE		0x1E
#define REG_CAN_EID			0x1F

//#define BASE_ADC 0x20

#define REG_DGAMMA    	 0x100 
#define REG_DGAMMA_LO  	 0x100 
#define REG_DGAMMA_HI  	 0x101 
#define REG_GAMMA   	 0x102
#define REG_D			 0x103
#define REG_Q			 0x104

#define FLASH_BASE 		 0x200
#define CLC_BASE 		 0xB00
#define REG_CLC_P1    	 0xB00
#define REG_CLC_V1    	 0xB01
#define REG_CLC_P2   	 0xB02
#define REG_CLC_V2   	 0xB03
#define REG_CLC_D1   	 0xB04
#define REG_CLC_D2   	 0xB05
#define REG_CLC_P1_SLOPE   	 0xB04
#define REG_CLC_V1_SLOPE   	 0xB05
#define REG_CLC_P2_SLOPE   	 0xB06
#define REG_CLC_V2_SLOPE   	 0xB07
#define REG_CLC_DAMPING   	 0xB08
#define REG_SLEWRATE_LIM   	 0xB09
#define REG_CLC_DAMPING_SLOPE  0xB0A
#define REG_CLC_CONTROL  0xB0B
#define REG_CLC_WINDUP_LIMIT  0xB0C
#define REG_DAMPING_K0  0xB0D

#define REG_FXGEN_BASE   0x400
#define REG_FXGEN        0x400
#define REG_AWG_SRATE    0x408
#define REG_AWG_START    0x409
#define REG_AWG_SIZE     0x40A
#define REG_AWG_REPLAYCOUNT 0x40B

#define REG_ADC_BASE   	 0x580

#define FXGEN_1_CODE      0x410
#define FXGEN_1_FREQ      0x411
#define FXGEN_1_PHASE     0x413
#define FXGEN_1_GAIN      0x414
#define FXGEN_1_OFFSET    0x415
#define FXGEN_1_PAR1      0x416
#define FXGEN_1_PAR2      0x418
#define FXGEN_1_PAR3      0x41A
#define FXGEN_1_PAR4      0x41C
		

#define REG_TEMP1_1      0x620
#define REG_TEMP1_2      0x621
#define REG_TEMP1_3      0x622
#define REG_TEMP1_4      0x623
#define REG_TEMP1_5      0x624
#define REG_TEMP1_6      0x625

#define REG_TEMP2_1      0x626
#define REG_TEMP2_2      0x627
#define REG_TEMP2_3      0x628
#define REG_TEMP2_4      0x629
#define REG_TEMP2_5      0x62A
#define REG_TEMP2_6      0x62B

#define REG_DEW		     0x62C

#define REG_APP_CFG	     0x800
#define REG_APP_MODE     0x800  
#define REG_APP_VREF     0x802  
#define REG_APP_IREF     0x804 
#define REG_APP_SETPOINT 0x806   
#define REG_APP_IMAX     0x80A   
 
#define REG_RINGINFO   0x25
#define REG_ETH_PHY0   0x900


#define REG_EEPROM_CTRL 0x0F00
#define REG_EEPROM_DATA 0x0E00

#define REG_HISTO_CMD  0x1000
#define REG_HISTO_DATA 0x1040

#define REG_CURRENT_TEST 0x2000
#define REG_DAQ_BASE   0x8000

#define REG_BIST       0x7000
#define REG_BIST_CTRL  0x7027


#define pi 3.141592654


#define EMULATE 0
#define DEBUG 0

#define BASE_DIR_CTRL 0x10

#define CONTROL_MODE_NONE 	0
#define CONTROL_MODE_EMC  	1
#define CONTROL_MODE_ADC  	2
#define CONTROL_MODE_FXGEN  3
#define CONTROL_MODE_AC3P  4

#define	INDEX_DCLINK 0
#define	INDEX_VOUTp  1
#define	INDEX_VOUTn  2
#define	INDEX_VREF   11
#define INDEX_IOUT   3
#define INDEX_IFILTER   10
#define INDEX_ILEG_1   4
#define INDEX_ILEG_2   5
#define INDEX_ILEG_3   6
#define INDEX_ILEG_4   7
#define INDEX_ILEG_5   8
#define INDEX_ILEG_6   9

//-----access to virtual COM -----------------------------------
void COM_openSerial(void);
void COM_GetStatus(void);
int COM_readByte(char *rxbuffer);
void COM_WriteCmdString(char *txbuffer); 

void writeCmd(int addr, int data);
void writeByte(int value8);
void readCmd(int addr, int *data);
void readByte(int *value8);
int  readString(int length, char *response);
void writeCmdString(char *cmdstring);

//--- flash functions ------------------------------------------
void SendBuffer(unsigned ID,char *buf, unsigned pagenumber, unsigned base);
void ReadPage(unsigned ID,char *buffer, unsigned pagenumber);
unsigned ReadStatus(unsigned ID);

int Load_MCS(char *fname);						  
void SendPage(unsigned ID,char *buf, unsigned addr);
void BulkErase(unsigned ID);
void WriteEnable(unsigned ID);
void GetBuffer(unsigned ID,char *rxbuffer,int pagenumber);
void scanline(FILE *fp, char *line);
unsigned convert(char *str, int start, int length);
unsigned ihex_checksum(char *buf,int length);

char txbuffer[0x400000];
char rxbuffer[0x400000];
extern FILE *fp_macro, *fp_can;

//---configuration --------------------------------------------
void LoadSetting(char *fname);
void SaveSetting(char *fname);
void Initialize(void);
void PWM_Control(void); 
void GetDirectCtrl(void);
void SendDirectCtrl(void);
void SetDirectCtrl(void);
void LoadCal (char *fname);
void SaveCal (char *fname);
void GetCal (void);
void AutoOffsetCal(void); 
void LoadHarmonics(char *fname);
void GetHarmonics(void);
void SaveHarmonics(char *fname);
void UpdateHarmonics(double mag, double arg);

void makePhaseTable(void);

void CreateReport(char *fname);

void AcquireRAW(void);

void Resize_Window_CurrentBalance(void);

void LogSettings(FILE *fp);
void Set_FXgen(void);

void Set_Mode(void);
void Configure_Mode(void);

//---CAN function prototypes-----------------
int  CAN_init(void);
void CAN_LoadConfig(char *fname);
void CAN_SaveConfig(char *fname);   
void Configure_Cycle(void);
void messega_tab_init(int id_offset);

void GetADC_Table(void);
void SetADC_Table(void);
void SaveADC_Table(char *fname);
void LoadADC_Table(char *fname);
void UpdateADC_Table(void);

void COM_LoadConfig(char *fname);
void COM_SaveConfig(char *fname) ;

void FXL_restore(char *fname);   

void RegisterServer(void);
void TCP_WriteString (char *buffer, int length);

void RegisterDump(char *fname);
void SetVector(int mode,int x,int y);   

void GetHistogram(int state,double freq,double level,double efield,int pol,int modulation, int niter) ;
void Macro_Snapshot(FILE *fp_macro); 	
void  Macro_Timestamp(unsigned timestamp,FILE *fp);
void Set_CLCPAR(int);

void RegisterDumpVerbosed(FILE *fout, char *fname);
void str_extend(char *str,int n);
void XML_Import_REGS(char *xml_fname);
void XML_Export_REGS(char *xml_fname,char *regtemplate_fname);
void XML_ExportOpConditions(char *xml_opcond_fname); 	

int Config_Testequipment(void);

void SaveEMCTest(char *fname);
double Read_E4416A(void); 
void set_siggen(float freq, float level, int modulation,int state);    
double get_efield (double freq,int pol);

 struct attr_struct {
	 char name[32];
	 char val[32];
 };
 
struct xml_element_struct {
		int level;
		char name[256];
		struct attr_struct attr[8];
		char content[1024];
};

extern unsigned UDP_rxbuffer[0x10000];


extern short int wavebuffer[3*1464*1000];
extern short int txwavebuffer[3*1464*1000];
struct session_struct {
	int nw_type;
	int can_id;
	char ip[32];
};
extern struct session_struct session;
extern int verbose;


void LoadSession(char *,struct session_struct *session);
void SaveSession(char *,struct session_struct *session);

void Initialize_UDPWriter(unsigned port_number);
void Close_UDPWriter(void);
int Initialize_UDPReader (unsigned port_number);
int Close_UDPReader(void);

int UDP_BlockReadRegister(int ID, int base, int offset, int *data, int number);
int UDP_BlockWriteRegister(int ID,int base, int offset, int *data, int number);
int UDP_WriteRegister(int ID,int address, int data);
int UDP_ReadRegister(int ID,int address, int *data, int number);
int UDP_SendRegs(int ID,int n, char *txbuf);
int UDP_WriteReadRegister(int ID_device, int addr_tx, int *data, int number,int addr_rx, int *data_rx, int num_rx);

int CAN_WriteRegister(int addr, int data);
int CAN_ReadRegister(unsigned address, int *reg, int length);
int CAN_RTR(int addr, int length);
int CAN_WriteDword(int addr, int data);
int CAN_ReadDword(unsigned address, int *reg);

int NW_WriteRegister(int ID,int addr, int data);
int NW_ReadRegister(int ID,unsigned address, int *reg, int length);
int NW_ReadRegisters(int ID,unsigned address, int *reg, int length);
int NW_RTR(int ID,int addr, int length);
int NW_WriteDword(int ID,int addr, int data);

//int UDP_BlockingRead(int ID,int *size, char *msg, char *resp);

void NW_dispatch(unsigned *buffer,unsigned base,unsigned n);   
void CreateTestPanel(void);
void CreateTestPanelB(void);

void Save_System_Cfg(int panel,char *fname);
void Load_System_Cfg(int panel,char *fname);
void System_Cfg(int panel,int control);      
void Setup_System_Mode(int val);
void Restore_System1_Config1(char *fname);
void Restore_System1_Config2(char *fname);
void Restore_System1_Config3(char *fname);

void Create_ADC_Waves(char *fname);  


extern void Initialize_UDPWriter(unsigned);
extern int Initialize_UDPReader(unsigned);
extern void Close_UDPWriter(void);
extern int Close_UDPReader(void);
extern int UDP_Send (char *cmdstring, int cmdlength);
extern int UDP_Send_DACPacket (char *cmdstring, int cmdlength);
extern int UDP_BlockingRead(int ID,int *size,char  *data, char *resp);

void Do_Acquire_Response(int acquire, int panel, int calc_response,double *ref_sin, double *ref_cos, double *response);
void comma_convert(char *);

void ASCII_ExportOpConditions(FILE *fp);
void ASCII_SaveEMCTest(FILE *fp);
void ASCII_ExportRegister(FILE *fp);

void LogOperatingConditions(char *fname,double current_freq,double current_level,double current_efield,double current_pol,double current_modulation,double n_iteration);
void ReadOperationalValues(double *temperature, int *dewpoint, unsigned *uptime,unsigned *stat, int *adc);

int GetDeviceNetworkState(int ID);
void SetDeviceNetworkState(int ID,int state);
void GetSystemID(int*ID1,int*ID2,int*ID3);

void LoadVS_PanelState(int panel);   
void SaveVS_PanelState(int panel);
void BodePlot(void);
void LegControl(int ID);
void SaveCLC_ParSet(char *fname, unsigned *par);
void GetCLC_Par1(void);
void Setup_CLC_TB(char *fname);

int GetID(int num);
int GetTestmodeID(void);
