 /*---------------------------------------------------------------------------*/
/*                                                                           */
/* FILE:    client.c                                                         */
/*                                                                           */
/* PURPOSE: This is a skeleton program to demonstrate how you would write a  */
/*          a TCP Client application. This program connects to an established*/
/*          TCP server and communicates via a user interface panel.  This    */
/*          sample only communicates with one server, but illustrates how to */
/*          implement a callback function to respond to TCP events.          */
/*                                                                           */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Include files                                                             */
/*---------------------------------------------------------------------------*/
#include <cvirte.h>
#include <stdio.h>
#include <stdlib.h>
#include <tcpsupp.h>
#include <string.h>
#include <utility.h>
#include <userint.h>
#include "fpga_control.h"

/*---------------------------------------------------------------------------*/
/* Macros                                                                    */
/*---------------------------------------------------------------------------*/
#define tcpChk(f) if ((g_TCPError=(f)) < 0) {ReportTCPError(); goto Done;} else

/*---------------------------------------------------------------------------*/
/* Internal function prototypes                                              */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClientTCPCB (unsigned handle, int event, int error,
                             void *callbackData);
static void ReportTCPError (void);

/*---------------------------------------------------------------------------*/
/* Module-globals                                                            */
/*---------------------------------------------------------------------------*/
static unsigned int g_hconversation;
static int          g_hmainPanel;
static int          g_connected = 0;
static int          g_TCPError = 0;

/*---------------------------------------------------------------------------*/
/* This is the application's entry-point.                                    */
/*---------------------------------------------------------------------------*/


unsigned milliseconds;
char str[64],str1[64],str2[64],str3[64],str4[64],str5[64],str6[64],str7[64],str8[64],str9[64],str10[64],str11[64],str12[64];

static char tmpBuffer[1024];
static int tmpPtr=0;

void TimeString(unsigned timestamp);
int SaveConfig(char *fname);
int LoadConfig(char *fname);
	
	

int tcp_init void)
{
    int  portNum;
    char tempBuf[256] = {0};
    //char portNumStr[32];
    
    if (InitCVIRTE (0, argv, 0) == 0)
        return -1;
    if ((g_hmainPanel = LoadPanel(0, "client.uir", MAINPNL)) < 0)
        goto Done;
    DisableBreakOnLibraryErrors();

    /* Prompt for the name of the server to connect to */
        //SetActiveCtrl (g_hmainPanel, MAINPNL_STRING);
	LoadConfig("config.txt");
    GetCtrlVal (g_hmainPanel, MAINPNL_SERVERNAME, tempBuf);
	
    //sprintf(tempBuf,"KPERSR4267");
	portNum = 10000;

    /* Attempt to connect to TCP server... */
   // SetWaitCursor (1);
    if (ConnectToTCPServer (&g_hconversation, portNum, tempBuf, ClientTCPCB,
                            NULL, 5000) < 0)
        MessagePopup("TCP Client", "Connection to server failed !");
	
    else
        {
   //     SetWaitCursor (0);
        g_connected = 1;
        
        /* We are successfully connected -- gather info */
        SetCtrlVal (g_hmainPanel, MAINPNL_CONNECTED, 1);
        if (GetTCPHostAddr (tempBuf, 256) >= 0)
            SetCtrlVal (g_hmainPanel, MAINPNL_CLIENT_IP, tempBuf);
        if (GetTCPHostName (tempBuf, 256) >= 0)
            SetCtrlVal (g_hmainPanel, MAINPNL_CLIENT_NAME, tempBuf);
    /*    tcpChk (GetTCPPeerAddr (g_hconversation, tempBuf, 256));
        SetCtrlVal (g_hmainPanel, MAINPNL_SERVER_IP, tempBuf);
        tcpChk (GetTCPPeerName (g_hconversation, tempBuf, 256));
        SetCtrlVal (g_hmainPanel, MAINPNL_SERVER_NAME, tempBuf);   */
        }
	
    /* display the panel and run the UI */
    DisplayPanel (g_hmainPanel);
    //SetActiveCtrl (g_hmainPanel, MAINPNL_STRING);
    RunUserInterface ();
	SaveConfig("config.txt");
         
    
Done:
    /* Disconnect from the TCP server */
    if (g_connected)
        DisconnectFromTCPServer (g_hconversation);

    /* Free resources and return */
    DiscardPanel (g_hmainPanel);
    CloseCVIRTE ();
    return 0;
}

int SaveConfig(char *fname)
{
	FILE *fp;
	char str[260];
	
	fp = fopen(fname,"w");
    GetCtrlVal (g_hmainPanel, MAINPNL_SERVERNAME, str);
 	fprintf(fp,"TCP Server Name %s\n",str);
	fclose(fp);
	return 0;
	
}

int LoadConfig(char *fname)
{
	FILE *fp;
	char str[260];
	
	fp = fopen(fname,"r");
 	fscanf(fp,"TCP Server Name %s\n",str);
    SetCtrlVal (g_hmainPanel, MAINPNL_SERVERNAME, str);
	fclose(fp);
	return 0;
	
}

/*---------------------------------------------------------------------------*/
/* When the user hits ENTER after typing some text, send it to the server... */
/*---------------------------------------------------------------------------*/
/*                            void *callbackData, int eventData1, int eventData2)
{
    char    transmitBuf[512] = {0};

    switch (event)
        {
        case EVENT_COMMIT:
            GetCtrlVal (panelHandle, MAINPNL_STRING, transmitBuf);
            strcat (transmitBuf, "\n");
            SetCtrlVal (panelHandle, MAINPNL_TRANSMIT, transmitBuf);
            SetCtrlVal (panelHandle, MAINPNL_STRING, "");
            if (ClientTCPWrite (g_hconversation, transmitBuf,
                                strlen (transmitBuf), 1000) < 0)
                SetCtrlVal (panelHandle, MAINPNL_TRANSMIT,
                            "Transmit Error\n");
            break;
        }
    return 0;
}
*/
/*---------------------------------------------------------------------------*/
/* This is the TCP client's TCP callback.  This function will receive event  */
/* notification, similar to a UI callback, whenever a TCP event occurs.      */
/* We'll respond to the DATAREADY event and read in the available data from  */
/* the server and display it.  We'll also respond to DISCONNECT events, and  */
/* tell the user when the server disconnects us.                             */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClientTCPCB (unsigned handle, int event, int error,
                             void *callbackData)
{
    char receiveBuf[1024] = {0};
    ssize_t dataSize         = sizeof (receiveBuf) - 1;
	int j;
	
    switch (event)
        {
        case TCP_DATAREADY:
           	if ((dataSize = ClientTCPRead (g_hconversation, receiveBuf, dataSize, 1000)) < 0)
                	{
                	printf("TCP Read ERROR!!!\n");
                	}
           	 	else
                	{
					//intf("dataSize = %d\n",dataSize);
					receiveBuf[dataSize]=0;
					for (j=0; j < dataSize; j++) {
               			if (receiveBuf[j] != 0x0A)  
						   tmpBuffer[tmpPtr++] = receiveBuf[j];
 						 
						else {
							tmpBuffer[tmpPtr++] = 0x0A;
							tmpBuffer[tmpPtr] = 0;
							SetCtrlVal (g_hmainPanel, MAINPNL_RECEIVE, tmpBuffer);
                			//SetCtrlVal (g_hmainPanel, MAINPNL_MESSAGESIZE, dataSize);
				    		sscanf(tmpBuffer,"%d %s %s %s %s %s %s %s %s %s %s %s %s\n",&milliseconds,str1,str2,str3,str4,str5,str6,str7,str8,str9,str10,str11,str12);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,1),ATTR_CTRL_VAL,str3);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,2),ATTR_CTRL_VAL,str4);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,3),ATTR_CTRL_VAL,str5);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,4),ATTR_CTRL_VAL,str6);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,5),ATTR_CTRL_VAL,str7);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_1,MakePoint(2,6),ATTR_CTRL_VAL,str8);

				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,1),ATTR_CTRL_VAL,str2);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,2),ATTR_CTRL_VAL,str1);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,3),ATTR_CTRL_VAL,str12);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,4),ATTR_CTRL_VAL,str9);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,5),ATTR_CTRL_VAL,str10);
				    		SetTableCellAttribute(g_hmainPanel,MAINPNL_TABLE_2,MakePoint(2,6),ATTR_CTRL_VAL,str11);
							
							tmpPtr = 0;
				    		TimeString(milliseconds); 
						    }
					    }
					}
 				break;
        case TCP_DISCONNECT:
            MessagePopup ("TCP Client", "Server has closed connection!");
            SetCtrlVal (g_hmainPanel, MAINPNL_CONNECTED, 0);
            g_connected = 0;
            MainPanelCB (0, EVENT_CLOSE, 0, 0, 0);
            break;
    }
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Respond to the UI and clear the receive screen for the user.              */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClearScreenCB (int panel, int control, int event,
                               void *callbackData, int eventData1,
                               int eventData2)
{
    if (event == EVENT_COMMIT)
        ResetTextBox (panel, MAINPNL_RECEIVE, "");
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Respond to the panel closure to quit the UI loop.                         */
/*---------------------------------------------------------------------------*/
int CVICALLBACK MainPanelCB (int panel, int event, void *callbackData,
                             int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
        QuitUserInterface (0);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Report TCP Errors if any                                                  */
/*---------------------------------------------------------------------------*/
static void ReportTCPError(void)
{
    if (g_TCPError < 0)
        {
        char    messageBuffer[1024];
        sprintf(messageBuffer, 
            "TCP library error message: %s\nSystem error message: %s", 
            GetTCPErrorString (g_TCPError), GetTCPSystemErrorString());
        MessagePopup ("Error", messageBuffer);
        g_TCPError = 0;
        }
}
/*---------------------------------------------------------------------------*/

 void TimeString(unsigned milliseconds)
 {
	unsigned seconds,minutes,hours,days;
	char time_string[32];
	int blank=0;
			
				seconds = milliseconds/1000;
				minutes = seconds/60;
				hours = seconds/3600;
				days = seconds/(24*3600);
				seconds %= 60;
				minutes %= 60;
				hours %= 24;
				blank=0;
			
				if (days){
					sprintf(time_string,"%3dd ",days);
					blank++;
				}
				else   
					sprintf(time_string,"     ");
			 
			
				if (hours) {
					if (blank) sprintf(time_string,"%s%02d:",time_string,hours);
					else sprintf(time_string,"%s%2d:",time_string,hours); 
					blank++;
				}
				else { 
					if (blank) sprintf(time_string,"%s%02d:",time_string,hours);
					else sprintf(time_string,"%s   ",time_string);
				}
				if (minutes) {
					if (blank)  sprintf(time_string,"%s%02d:",time_string,minutes);
					else sprintf(time_string,"%s%2d:",time_string,minutes);
				    blank++;
				}
				else { 
					if (blank)  sprintf(time_string,"%s%02d:",time_string,minutes);
					else sprintf(time_string,"%s   ",time_string);
				}
				if (blank) sprintf(time_string,"%s%02d",time_string,seconds);
				else sprintf(time_string,"%s%2d",time_string,seconds);
				
                SetCtrlVal (g_hmainPanel, MAINPNL_TIMESTAMP, time_string);
 }
