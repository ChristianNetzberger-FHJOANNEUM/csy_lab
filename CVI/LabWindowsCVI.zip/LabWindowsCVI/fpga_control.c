#include <tcpsupp.h>
#include <analysis.h>
#include "easytab.h"
#include <rs232.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "fpga_control.h"

#include "defs.h"


#define pi 3.141592654

#define DEBUG 0

//===================================================================================================================================
//
//   Globals
//
//===================================================================================================================================

int netInterface=0;

int mainHandle, comHandle, cfgHandle, txHandle, audHandle, serHandle;
int comport, baudrate;
unsigned tabCtrl;

int online = 0;

void GetStatus(void);
void writeCmd(int addr, int data);
void writeByte(int value8);
void readCmd(int addr, int *data);
void readByte(int *value8);
void readChar(char *ch);
void  ReadResponse(char *ch);


void LoadConfig(char *fname);
void SaveConfig(char *fname);
void Initialize(void);
void openSerial(void);

FILE *fplog;


void WriteRegister(unsigned addr, unsigned data);
void writeCmdString(char *cmdstring);
void LoadSettings(char *fname);
void SaveSettings(char *fname);
void openSerial(void);
void closeSerial(void);
void openNetif(void);



#define NSPECTRUM 2048
double fft_data[4096];

double spectrum_r[NSPECTRUM],spectrum_i[NSPECTRUM],spectrum_mag[NSPECTRUM],spectrum_arg[NSPECTRUM];
unsigned temp[100];

int	TimerHandlerEnable = 1;


//-----------------------------------------------------------------------------------------
//
//                 M A I N
//
//-----------------------------------------------------------------------------------------



int main (int argc, char *argv[])
{
    int stat, try_comport;
	int sw_version;
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((mainHandle = LoadPanel (0, "fpga_control.uir", PANEL_MAIN)) < 0)
		return -1;
	DisplayPanel (mainHandle);
	
	//-- Load Tabs ---------
    tabCtrl = EasyTab_ConvertFromCanvas(mainHandle, PANEL_MAIN_CANVAS);
	EasyTab_LoadPanels (mainHandle, tabCtrl, 1, "fpga_control.uir", __CVIUserHInst,
						PANEL_COM, &comHandle,
						PANEL_SER, &serHandle,
						PANEL_TX, &txHandle,
						PANEL_AUD, &audHandle,
						0);
	EasyTab_SetAttribute (mainHandle, tabCtrl,
						  ATTR_EASY_TAB_ACTIVE_PANEL, txHandle);

    
	LoadConfig("config.txt");

	netInterface = 0;
    openNetif();
	
	
//	GetSW_Version(&sw_version);
//	SetCtrlVal(mainHandle,PANEL_MAIN_SW_VERSION,sw_version);
	
	//---Run the User Interface--------------------------
	SetBreakOnLibraryErrors (0);

	RunUserInterface ();
	//-----close serial interface and
	if (online)
       CloseCom (comport);
	
	//-----close serial interface and
	SaveConfig("config.txt");
	DiscardPanel (mainHandle);
																						 
	return 0;
}

//----------------------------------------------------------------------------
//
//	  Network Interface
//
//----------------------------------------------------------------------------

void openNetif(void)
{
	if (netInterface == 1) {
		SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,1);
		openSerial();
	}
}


//-----------------------------------------------------------------------------------------
//
//                 Serial C O N S O L E 
//
//-----------------------------------------------------------------------------------------


void openSerial(void)
{
	int try_comport,stat;
	
		//-- Initialize Serial Port ------------------
	GetCtrlVal(comHandle,PANEL_COM_COM,&comport);
	GetCtrlVal(comHandle,PANEL_COM_BAUDRATE,&baudrate);
	
	//--try several COM: ports since actual comport may be unknown----
    try_comport = 1;
	online = 0;
    do{ 
      stat = OpenComConfig (comport, "", baudrate, 0, 8, 1, 512, 512);
      if (stat) {
	     MessagePopup ("ERROR", "COM Port: not opened");
	      SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
	     try_comport--;
	   //  comport++;
	     }
	  else {
		  online = 1;
	      try_comport = 0;
	      SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,1);
	      }
  	  } while(try_comport);
	
	SetCtrlVal(comHandle,PANEL_COM_COM,comport);
}

void closeSerial(void)
{
   CloseCom (comport);     	
   SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
   online = 0;
}


void Serial_Online(void)
{
	unsigned val;
	
	GetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,&val);
	if (val) {
		netInterface = 1;
		openSerial();
	}
	else {
		netInterface = 0;
		closeSerial();
	}
	
}


void LoadConfig(char *fname)
{
	FILE *fp;
	
	int val;
	char str[260];
	
	fp = fopen(fname,"r");
	if (fp==NULL) return;
	
	fscanf(fp,"COM %d\n",&val);
	SetCtrlVal(comHandle,PANEL_COM_COM,val);
	fscanf(fp,"BAUDRATE %d\n",&val);
	SetCtrlVal(comHandle,PANEL_COM_BAUDRATE,val);
	
	if (netInterface == 0) {
		SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
	}
	
	if (netInterface == 1)
		SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,1);
	else
		SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
	
	
	fclose(fp);
}

void SaveConfig(char *fname)
{
	FILE *fp;
	char str[260];
	
	int val;
	
	fp = fopen(fname,"w");
	
	GetCtrlVal(comHandle,PANEL_COM_COM,&val);
	fprintf(fp,"COM %d\n",val);
	GetCtrlVal(comHandle,PANEL_COM_BAUDRATE,&val);
	fprintf(fp,"BAUDRATE %d\n",val);

	GetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,&val);
	
    fprintf(fp,"INTERFACE %d  0=OFF 1=COM \n",netInterface);

	fclose(fp);
}



  //-----------------------------------------------------------------------------------------
//
//                  R E G I S T E R   ACCESS
//
//-----------------------------------------------------------------------------------------

void WriteRegister(unsigned addr, unsigned data)
{
	char str[32],str_tb[64];
	int val;
	int netif;
	int i;
	
//	sprintf(str,"<wr %X %X>\n\r",addr,data);
	sprintf(str,"wr %X %X\r\n",addr,data);
//	printf("%s",str);
	
	writeCmdString(str);
	
	sprintf(str,"wr %X %X\r\n",addr,data);
	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
	if ((val) && (addr != 1))printf("%s",str);
}


void WriteRegisterN(unsigned addr, unsigned data)
{
	char str[1024],str_tb[64];
	int val;
	int netif;
	int i;
	int num = 5;
	
	
	sprintf(str,"<wrn %X %X",addr,num);
	for (i=0; i < num; i++)
	   sprintf(str,"%s %X",str,data+i);
		
	sprintf(str,"%s>\n\r",str);
//	printf("%s",str);
	writeCmdString(str);
//	sprintf(str,"wr %X %X\r\n",addr,data);
	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
	if (val)printf("%s",str);
}

void WriteMemory(unsigned addr, unsigned data, unsigned base)
{
	 
	char str[32],str_tb[64];
	int val;
	int netif;
	
	sprintf(str,"<wm %X %X>\n\r",addr,data);
//	printf("%s",str);
	writeCmdString(str);
	
	sprintf(str,"wm %X %X\r\n",addr,data);
	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
	if (val)printf("%s",str);
 
}

void WriteMemoryN(unsigned addr, unsigned data, unsigned base)
{

	char str[1024],str_tb[64];
	int val;
	int netif;
	int i;
	int num = 5;
	int interleave = 2;
	
	
	sprintf(str,"<wmn %X %X %X",addr,num,interleave);
	for (i=0; i < num; i++)
	   sprintf(str,"%s %X",str,data+i);
		
	sprintf(str,"%s>\n\r",str);
//	printf("%s",str);
	writeCmdString(str);
	
//	sprintf(str,"wr %X %X\r\n",addr,data);
	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
	if (val)printf("%s",str);
	
}



void ReadRegister(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   char resp[32000];
   int val;
	int netif;
	unsigned uval;
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   
	   //sprintf(str,"<rr %X>\r\n",addr);
 	   sprintf(str,"rr %X\r\n",addr);


	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
		if ((val) && (addr > 1))  printf("%s",str);
	
	   if (online == 0) {
		   *data = 0;
		   return;
	   }
	   FlushInQ (comport);
	   writeCmdString(str); 

	   readByte(&tmp1);
	   readByte(&tmp2);
	   readByte(&tmp3);
	   readByte(&tmp4);
	   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
	
}

void ReadMemory(int addr, int *data, unsigned base)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   char resp[32000];
   int val;
	int netif;
	unsigned uval;
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   
	sprintf(str,"<rm %X>\r\n",addr);
	GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
		if (val)  printf("%s",str);

	   if (online == 0) {
		   *data = 0;
		   return;
	   }
	   FlushInQ (comport);
	   writeCmdString(str); 

	   readByte(&tmp1);
	   readByte(&tmp2);
	   readByte(&tmp3);
	   readByte(&tmp4);
	   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
	
	   sprintf(str,"rr %X --> %X\r\n",addr,*data);

	   GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
		if ((val) && ( addr >  3) && (addr != 9)) printf("%s",str);
}

int scanstr(char *str,unsigned *data,unsigned num)
{
	 int n = 0;														    
	 unsigned ptr = 0;
	 int k = 0;
	 int state = 0;
	 
	 while ( n < strlen(str)) {
		 switch (state) {
			 case 0: if (str[n] > 0x20) {
					     sscanf(str+n,"%08X",data+k);
						 k++;
				         state = 1;
					 }
					 break;
			 case 1: if (str[n] <= 0x20)  
			             state = 0;
					 break;
			 }
			 n++;
	 };
	return k;
}

void ReadMemoryN(int addr, int *data, unsigned base)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   char resp[32000];
   int val;
	int netif;
	unsigned uval;
	unsigned num = 5;
	unsigned interleave = 2;
	int k;
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   
	sprintf(str,"<rmn %X %X %X>\r\n",addr,num,interleave);

	   if (online == 0) {
		   *data = 0;
		   return;
	   }
	   FlushInQ (comport);
	   writeCmdString(str); 

	   for (k=0; k < num; k++) {
		   readByte(&tmp1);
		   readByte(&tmp2);
		   readByte(&tmp3);
		   readByte(&tmp4);
		   *(data+k) = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
	   }
	   sprintf(str,"rr %X --> %X\r\n",addr,*data);

	   GetCtrlVal(mainHandle,PANEL_MAIN_COM_DEBUG,&val);
		if ((val) && ( addr >  3) && (addr != 9)) printf("%s",str);
}


void ReadBuffer(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   if (online == 0) {
	   *data = 0;
	   return;
   }

   FlushInQ (comport);
   sprintf(str,"b %X\r\n",addr);
   writeCmdString(str); 
   readByte(&tmp1);
   readByte(&tmp2);
   readByte(&tmp3);
   readByte(&tmp4);
   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
}

void writeByte(int value8)
{
	char str[4];
    unsigned bytes_written;
    
	sprintf(str,"%02X",value8);
	
	bytes_written = ComWrtByte (comport, str[0]);
	bytes_written = ComWrtByte (comport, str[1]);
	
}

void readByte(int *value8)
{
	char str[4];
	int i;
	int queuelength;

   if (online == 0) {
	   *value8 = 0;
	   return;
   }
   i=0;
   do {
	queuelength = GetInQLen (comport);
	i++;
   } while ((i < 0x10000) && (queuelength == 0));
 	if (queuelength)
	   str[0] = ComRdByte (comport);
	else {
		str[0] =0;
		MessagePopup ("Serial Interface", "No Response from Target !");
	    SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
		online = 0;
		return;
	}
   do {
	queuelength = GetInQLen (comport);
	i++;
   } while ((i < 0x10000) && (queuelength == 0));
	str[1] = ComRdByte (comport);
	str[2] = 0;
	sscanf(str,"%X",value8);
//	if (readByteTrace)
//		printf("%s",str);
}

void writeCmdString(char *cmdstring)
{  
   unsigned bytes_written;
   int i;
   
   if (online == 0) return;
   FlushInQ (comport);
   for (i=0; i < strlen(cmdstring); i++)
      ComWrtByte (comport, cmdstring[i]);
}

/*

//-----------------------------------------------------------------------------------------
//
//                  R E G I S T E R   ACCESS
//
//-----------------------------------------------------------------------------------------
 */

void WriteDRegister(unsigned addr, unsigned data)
{
  WriteRegister( addr,  data & 0xFFFF); 
  WriteRegister( addr+1, (data >>16) & 0xFFFF); 
}







/*
void ReadBuffer(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   if (online == 0) {
	   *data = 0;
	   return;
   }

   FlushInQ (comport);
   sprintf(str,"b %d\r\n",addr);
   writeCmdString(str); 
   readByte(&tmp1);
   readByte(&tmp2);
   readByte(&tmp3);
   readByte(&tmp4);
   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
}

void writeByte(int value8)
{
	char str[4];
    unsigned bytes_written;
    
	sprintf(str,"%02X",value8);
	
	bytes_written = ComWrtByte (comport, str[0]);
	bytes_written = ComWrtByte (comport, str[1]);
	
}

void readByte(int *value8)
{
	char str[4];
	int i;
	int queuelength;

   if (online == 0) {
	   *value8 = 0;
	   return;
   }
	for (i=0;i<0x40000;i++);
	queuelength = GetInQLen (comport);
	if (queuelength)
	   str[0] = ComRdByte (comport);
	else {
		str[0] =0;
	if (DEBUG==2)	printf("#");
		return;
	}
	for (i=0;i<0x10000;i++);
	str[1] = ComRdByte (comport);
	str[2] = 0;
	sscanf(str,"%X",value8);
	if (DEBUG==2) printf(" %s",str);
	
}

void readChar(char *ch)
{
	char str[4];
	int i;
	int queuelength;

   if (online == 0) {
	   *ch = 0;
	   return;
   }
	for (i=0;i<0x888000;i++);
	queuelength = GetInQLen (comport);
	if (queuelength)
	   *ch = ComRdByte (comport);
	else {
		str[0] =0;
		return;
	}
	
}
void  ReadResponse(char *ch)
{
	char str[4];
	int i;
	int queuelength;

   if (online == 0) {
	   *ch = 0;
	   return;
   }
	for (i=0;i<0x100000;i++);
	queuelength = GetInQLen (comport);
	if (queuelength > 29) queuelength = 29;
	for (i=0; i < 21; i++)  
	   *(ch+i) = ComRdByte (comport);
	for (i=0; i < queuelength-21; i++) {
	   *(ch+i) = ComRdByte (comport);
	   if (*(ch+i) < 0x20)
		   *(ch+i) = '*';
	}
    *(ch+i) = 0;
	return;
	 
	
}

void writeCmdString(char *cmdstring)
{  
   unsigned bytes_written;
   int i;
   
   if (online == 0) return;
   FlushInQ (comport);
   for (i=0; i < strlen(cmdstring); i++)
      ComWrtByte (comport, cmdstring[i]);
}


 */

unsigned hexval(char ch)
{
	unsigned tmp;
	if (ch > '9')
	  tmp = ch - 0x37;
	else
	  tmp = ch - 0x30;
	return(tmp);
}

unsigned convert(char *str, int start, int length)
{
	int i;
	unsigned tmp = 0;
	
	for (i=start; i < start+length; i++) {
		tmp <<= 4;
		tmp += hexval(str[i]);
	}
   return(tmp);	
}


//-----------------------------------------------------------------------------------------
//
//                  T I M E R  CALLBACK
//
//-----------------------------------------------------------------------------------------


int CVICALLBACK CB_TIMER (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	unsigned reg_data,reg_addr;
	int i;
	unsigned y[2];
	unsigned val;
	unsigned milliseconds=0;
	unsigned seconds=0;
	unsigned minutes=0;
	unsigned hours=0;
	unsigned days=0;
	char time_string[32];
	int blank=0;
	char logstr[1024];
	char str[64];
	
	switch (event)
	{
		case EVENT_TIMER_TICK:
			
   if ((	TimerHandlerEnable == 0) ) return 0;
   
			
			ReadRegister(0x00,&reg_data);
			SetCtrlVal(mainHandle,PANEL_MAIN_HW_VERSION,reg_data & 0xFFFF);
			SetCtrlVal(mainHandle,PANEL_MAIN_HW_SERIALNUM,(reg_data>>16) & 0xFFFF);

			//----uptime------------------------------------
			ReadRegister(0x01,&reg_data);
			milliseconds = reg_data;
			seconds = milliseconds/1000;
			minutes = seconds/60;
			hours = seconds/3600;
			days = seconds/(24*3600);
			seconds %= 60;
			minutes %= 60;
			hours %= 24;
			blank=0;
		
			if (days){
				sprintf(time_string,"%3dd ",days);
				blank++;
			}
			else   
				sprintf(time_string,"     ");
		 
		
			if (hours) {
				if (blank) sprintf(time_string,"%s%02d:",time_string,hours);
				else sprintf(time_string,"%s%2d:",time_string,hours); 
				blank++;
			}
			else { 
				if (blank) sprintf(time_string,"%s%02d:",time_string,hours);
				else sprintf(time_string,"%s   ",time_string);
			}
			if (minutes) {
				if (blank)  sprintf(time_string,"%s%02d:",time_string,minutes);
				else sprintf(time_string,"%s%2d:",time_string,minutes);
			    blank++;
			}
			else { 
				if (blank)  sprintf(time_string,"%s%02d:",time_string,minutes);
				else sprintf(time_string,"%s   ",time_string);
			}
			if (blank) sprintf(time_string,"%s%02d",time_string,seconds);
			else sprintf(time_string,"%s%2d",time_string,seconds);
			
			SetCtrlVal(mainHandle,PANEL_MAIN_TIMESTAMP1,time_string);
			
			
			
			break;
	}
	return 0;
}





int CVICALLBACK CB_LEDTEST (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			break;
	}
	return 0;
}


int CVICALLBACK CB_CTRL (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

		
			break;
	}
	return 0;
}

int CVICALLBACK CB_READ_REG (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    unsigned reg_addr, reg_data,val;
    
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_READ_REG_ADDR,&reg_addr);
			GetCtrlVal(comHandle,PANEL_COM_REGISTER_BASE,&val);
			if (val)
			   ReadRegister(reg_addr,&reg_data);
			else
			   ReadMemory(reg_addr,&reg_data,0);
				
			SetCtrlVal(comHandle,PANEL_COM_READ_REG_DATA,reg_data);
			
			break;
		}
	return 0;
}

int CVICALLBACK CB_WRITE_REG (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    unsigned reg_addr, reg_data,val;
	char str[32];
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_WRITE_REG_ADDR,&reg_addr);
			GetCtrlVal(comHandle,PANEL_COM_WRITE_REG_DATA,&reg_data);
			GetCtrlVal(comHandle,PANEL_COM_REGISTER_BASE,&val);
			if (val)
			  WriteRegister(reg_addr,reg_data);
			else
			  WriteMemory(reg_addr,reg_data,0);
				
			/*
			//writeCmd(reg_addr,reg_data);
			sprintf(str,"w %d %d\r\n",reg_addr,reg_data);
			//printf("%s",str);
			writeCmdString(str);
			*/
			break;
		}
	return 0;
}

int CVICALLBACK CB_EXIT (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
		}
	return 0;
}



int CVICALLBACK CB_COM_CFG (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    int stat;
	switch (event)
		{
		case EVENT_COMMIT:
            CloseCom (comport);
			GetCtrlVal(comHandle,PANEL_COM_COM,&comport);
         	GetCtrlVal(comHandle,PANEL_COM_BAUDRATE,&baudrate);
			stat = OpenComConfig (comport, "", baudrate, 0, 8, 1, 512, 4096);
            if (stat)
	          MessagePopup ("ERROR", "COM Port: not opened");

			break;
		}
	return 0;
}






int CVICALLBACK CB_READ_BUF (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    unsigned reg_addr, reg_data;
    
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_READ_REG_ADDR,&reg_addr);
			ReadBuffer(reg_addr,&reg_data);
			SetCtrlVal(comHandle,PANEL_COM_READ_REG_DATA,reg_data);
			
			break;
		}
	return 0;
}





int CVICALLBACK CB_TIMER_HANDLER_ENABLE (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			break;
	}
	return 0;
}

int CVICALLBACK CB_ONLINE (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Serial_Online();
			break;
	}
	return 0;
}


int CVICALLBACK CB_WRITE_REGN (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			break;
	}
	return 0;
}

void Create_TestWAV(void)
{
	
	FILE *fp;
	int fsig=400;
	int fsamp = 40000;
	double val0,val1;
	short intval0,intval1;
	int i;
	unsigned accu = 0;

	fp = fopen("sinewav2.bin","wb");
	
	for (i=0; i < fsamp*60; i++)  {
		val0 = sin(2*pi*i*fsig/fsamp);
		val1 = sin(2*pi*i*fsig/(2*fsamp));
		intval0 = (int)(10000*val0);
		intval1 = (int)(10000*val1);
		fprintf(fp,"%c%c%c%c", (intval0&0xFF),(intval0 >> 8),  (intval1 & 0xFF),(intval1 >> 8));
	}
	
	fclose(fp);
	fp = fopen("ramp.bin","wb");
	
	for (i=0; i < fsamp*60; i++)  {
		val0 =  ((65535*i*fsig/fsamp) % 65535) -32768;
		val1 =  ((65535*i*fsig/(2*fsamp)) % 65535) -32768;     
		intval0 = (int)(val0);
		intval1 = (int)(val1);
		fprintf(fp,"%c%c%c%c", (intval0&0xFF),(intval0 >> 8),  (intval1 & 0xFF),(intval1 >> 8));
	}
	
	fclose(fp);
	fp = fopen("mixed.bin","wb");
	
	for (i=0; i < fsamp*60; i++)  {
		val0 = 32000*sin(2*pi*i/100);
		val1 =  ((64000*i/100) % 64000) -32000;  
		accu += 640;
		accu = accu % 64000;
		intval0 = (short int)(val0);
		intval1 = (short int)(accu - 32767);
		fprintf(fp,"%c%c%c%c", (intval0&0xFF),(intval0 >> 8),  (intval1 & 0xFF),(intval1 >> 8));
	}
	
	fclose(fp);
}


int CVICALLBACK CB_TESTWAV (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Create_TestWAV();
			break;
	}
	return 0;
}


int CVICALLBACK CB_SWITCH (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			break;
	}
	return 0;
}

void SetLeds(void)
{
	unsigned led0,led1,led2,led3;
	unsigned reg_addr,reg_data;
	
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_LED0,&led0);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_LED1,&led1);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_LED2,&led2);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_LED3,&led3);
	
	reg_addr = 0x100C;
	reg_data = 0;
	if (led0) reg_data |= (1<<20);
	if (led1) reg_data |= (1<<21);
	if (led2) reg_data |= (1<<22);
	if (led3) reg_data |= (1<<23);
	
    WriteRegister(reg_addr,reg_data); 	
}

void SetupTx(void)
{
	unsigned reg_addr,reg_data;
	unsigned bb_level, bb_offset;
	double bb_frequency;
	unsigned rf_level;
	double rf_frequency;
	unsigned bb_wavsel;
	unsigned cw,am,fm;
	double bb_fcw, rf_fcw;
	/*
	---register 4 to A ---
	audio_ctrl <= reg04;
	fcw_baseband <= reg05;
	level_baseband <= reg06(15 downto 0);
	offset_baseband <= reg06(31 downto 16);
	fcw_carrier <= reg07;
	level_carrier <= reg08(15 downto 0);
	wavesel <= reg09(3 downto 0);
	modsel <= reg0A(1 downto 0);
	*/
	
	
	GetCtrlVal(txHandle,PANEL_TX_BB_LEVEL, &bb_level);
	GetCtrlVal(txHandle,PANEL_TX_BB_OFFSET,&bb_offset);
	GetCtrlVal(txHandle,PANEL_TX_BB_FREQUENCY,&bb_frequency);
	GetCtrlVal(txHandle,PANEL_TX_RF_LEVEL,&rf_level);
	GetCtrlVal(txHandle,PANEL_TX_RF_FREQUENCY,&rf_frequency);
	GetCtrlVal(txHandle,PANEL_TX_BB_WAVSEL,&bb_wavsel);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_CW,&cw);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_AM,&am);
	GetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_FM,&fm);
	
	//---baseband settings------
	//  f = fclk*FCW/2**32  FCW = f* 2**32 / 108e6
	bb_fcw = (bb_frequency*1000)/1.08e8*65536*65536;
	reg_data = (unsigned) bb_fcw;
	reg_addr = 0x2005;
    WriteRegister(reg_addr,reg_data); 
	
	reg_data = ((bb_offset*150) << 16) + (bb_level*150);
	reg_addr = 0x2006;
    WriteRegister(reg_addr,reg_data); 	

	//---rf settings------
	//  f = fclk*FCW/2**32  FCW = f* 2**32 / 108e6
	rf_fcw = (rf_frequency*1e6)/1.08e8*65536*65536;
	reg_data = (unsigned) rf_fcw;
	reg_addr = 0x2007;
    WriteRegister(reg_addr,reg_data); 
	
 	reg_data = rf_level*300;
	reg_addr = 0x2008;
    WriteRegister(reg_addr,reg_data); 
	
	//--bb waveform select
 	reg_data = bb_wavsel;
	reg_addr = 0x2009;
    WriteRegister(reg_addr,reg_data); 
	
	reg_data = 0;
	if (cw) reg_data = 0;
	if (am) reg_data = 1;
	if (fm) reg_data = 2;
	reg_addr = 0x200A;
    WriteRegister(reg_addr,reg_data); 	
	
	
}

int CVICALLBACK CB_LEDS (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetLeds();
			break;
	}
	return 0;
}

int CVICALLBACK CB_SETUP_TX (int panel, int control, int event,
							 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetupTx();
			break;
	}
	return 0;
}

int CVICALLBACK CB_SET_FM (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_CW,0);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_AM,0);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_FM,1);
			SetupTx();

			break;
	}
	return 0;
}

int CVICALLBACK CB_SET_AM (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_CW,0);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_AM,1);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_FM,0);
			SetupTx();

			break;
	}
	return 0;
}

int CVICALLBACK CB_SET_CW (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_CW,1);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_AM,0);
			SetCtrlVal(txHandle,PANEL_TX_RADIOBUTTON_FM,0);
			SetupTx();
			break;
	}
	return 0;
}

void Setup_Audio(void)
{
	unsigned mute_left, mute_right,mono;
	unsigned quantization;
	unsigned filter;
	unsigned volumne;
	unsigned reg_addr, reg_data;
	
	/*
	- audio_functions 
	mute_left <= ctrl_0(0);
	mute_right <= ctrl_0(1);
	mono <= ctrl_0(2);  
	filter_on <= ctrl_0(3);
	filter_hp_lpn <= ctrl_0(4);
	volumne <= ctrl_1;
	balance <= ctrl_2;     
	quant <= ctrl_3(3 downto 0);
	*/
	GetCtrlVal(audHandle,PANEL_AUD_RADIOBUTTON_MUTE_L,&mute_left);
	GetCtrlVal(audHandle,PANEL_AUD_RADIOBUTTON_MUTE_R,&mute_right);
	GetCtrlVal(audHandle,PANEL_AUD_RADIOBUTTON_MONO,&mono);
	GetCtrlVal(audHandle,PANEL_AUD_FILTER,&filter);
	GetCtrlVal(audHandle,PANEL_AUD_VOLUMNE,&volumne);
	GetCtrlVal(audHandle,PANEL_AUD_QUANTIZATION,&quantization);
	
	//---baseband settings------
	reg_data = 0;
	if (mute_left)   reg_data |= 1;
	if (mute_right)  reg_data |= 2;
	if (mono)        reg_data |= 4;
	if (filter == 1) reg_data |= 8;
	if (filter == 2) reg_data |= 0x18;
	
	//--volumne
	reg_data |= (volumne << 8);
	reg_data |= (quantization << 24);
	
	reg_addr = 0x200B;
    WriteRegister(reg_addr,reg_data); 
	
	
}

int CVICALLBACK CB_AUDIO (int panel, int control, int event,
						  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Setup_Audio();
			break;
	}
	return 0;
}

int CVICALLBACK CB_FINC (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	double rf_inc,rf;
	
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(txHandle,PANEL_TX_RF_INC,&rf_inc);
			GetCtrlVal(txHandle,PANEL_TX_RF_FREQUENCY,&rf);
			SetCtrlVal(txHandle,PANEL_TX_RF_FREQUENCY,rf+rf_inc*1e-6);
			SetupTx();
			break;
	}
	return 0;
}

int CVICALLBACK CB_FDEC (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	double rf_inc,rf;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(txHandle,PANEL_TX_RF_INC,&rf_inc);
			GetCtrlVal(txHandle,PANEL_TX_RF_FREQUENCY,&rf);
			SetCtrlVal(txHandle,PANEL_TX_RF_FREQUENCY,rf-rf_inc*1e-6);
			SetupTx();

			break;
	}
	return 0;
}

void SerialSettings(void)
{
	double bitrate;
	unsigned fcw;
	
	GetCtrlVal(serHandle,PANEL_SER_SERIAL_BITRATE,&bitrate);
	fcw=(unsigned)(bitrate/100.0*65536.0*65536.0);
	WriteRegister(0x2002,fcw);
	
}


int CVICALLBACK CB_SERIAL_SETUP (int panel, int control, int event,
								   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			  SerialSettings();
			break;
	}
	return 0;
}
