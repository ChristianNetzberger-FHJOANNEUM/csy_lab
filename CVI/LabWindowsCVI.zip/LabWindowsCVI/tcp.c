#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include <tcpsupp.h>
#include "fpga_control.h"   


unsigned milliseconds;
char str[64],str1[64],str2[64],str3[64],str4[64],str5[64],str6[64],str7[64],str8[64],str9[64],str10[64],str11[64],str12[64];

static char tmpBuffer[1024];
static int tmpPtr=0;
extern int clientHandle,mainHandle;
extern int netInterface;

extern int SCPI;
int ClientWrite(char *msg);
int ClientRegRead(char *msg,char *resp);


int rxFlag = 0;

/*---------------------------------------------------------------------------*/
/* Internal function prototypes                                              */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClientTCPCB (unsigned handle, int event, int error,
                             void *callbackData);
static void ReportTCPError (void);

/*---------------------------------------------------------------------------*/
/* Module-globals                                                            */
/*---------------------------------------------------------------------------*/
static unsigned int g_hconversation;
static int          tcpHandle;
static int          g_connected = 0;
static int          g_TCPError = 0;

/*---------------------------------------------------------------------------*/
/* This is the application's entry-point.                                    */
/*---------------------------------------------------------------------------*/


int startClient(void)
{
    int  portNum;
    char servername[256] = {0};
    char tempBuf[256] = {0};
    //char portNumStr[32];
    
//    DisableBreakOnLibraryErrors();

    /* Prompt for the name of the server to connect to */
        //SetActiveCtrl (clientHandle, PANEL_TCP_STRING);
    GetCtrlVal (clientHandle, PANEL_TCP_SERVERNAME, servername);
	
//    sprintf(tempBuf,"10.52.254.250");
	if (SCPI)
		portNum = 5000;
	else
	    portNum = 5000;

    /* Attempt to connect to TCP server... */
   // SetWaitCursor (1);
    if (ConnectToTCPServer (&g_hconversation, portNum, servername, ClientTCPCB,
                            NULL, 5000) < 0)  {
		SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_TCP,0);
        MessagePopup("TCP Client", "Connection to server failed !");
	}
    else
        {
   //     SetWaitCursor (0);
        g_connected = 1;
        SetCtrlVal (clientHandle, PANEL_TCP_CONVERSATION, g_hconversation);
        
        /* We are successfully connected -- gather info */
        SetCtrlVal (clientHandle, PANEL_TCP_CONNECTED, 1);
        if (GetTCPHostAddr (tempBuf, 256) >= 0)
            SetCtrlVal (clientHandle, PANEL_TCP_CLIENT_IP, tempBuf);
        if (GetTCPHostName (tempBuf, 256) >= 0)
            SetCtrlVal (clientHandle, PANEL_TCP_CLIENT_NAME, tempBuf);
      //  GetTCPPeerAddr (g_hconversation, tempBuf, 256);
      //  SetCtrlVal (clientHandle, PANEL_TCP_SERVER_IP, tempBuf);
      //  GetTCPPeerName (g_hconversation, tempBuf, 256);
      //  SetCtrlVal (clientHandle, PANEL_TCP_SERVER_NAME, tempBuf);   
        }
	
    /* display the panel and run the UI */
	return 0;
}

    
int closeClient(void)
{						/* Disconnect from the TCP server */
    if (g_connected)
        DisconnectFromTCPServer (g_hconversation);

																																									 
    return 0;
}
/*---------------------------------------------------------------------------*/
/* This is the TCP client's TCP callback.  This function will receive event  */
/* notification, similar to a UI callback, whenever a TCP event occurs.      */
/* We'll respond to the DATAREADY event and read in the available data from  */
/* the server and display it.  We'll also respond to DISCONNECT events, and  */
/* tell the user when the server disconnects us.                             */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClientTCPCB (unsigned handle, int event, int error,
                             void *callbackData)
{
    char receiveBuf[1024] = {0};
    ssize_t dataSize         = sizeof (receiveBuf) - 1;
	int j;
	
    switch (event)
        {
        case TCP_DATAREADY: break;
           	if ((dataSize = ClientTCPRead (g_hconversation, receiveBuf, dataSize, 1000)) < 0)
                	{
                	printf("TCP Read ERROR!!!\n");
                	}
           	 	else
                	{
					printf("dataSize = %d\n",dataSize);
					//receiveBuf[dataSize]=0;
					for (j=0; j < dataSize; j++) {
               			if (receiveBuf[j] >= 0x20) { 
						   tmpBuffer[tmpPtr++] = receiveBuf[j];
						   printf("%c",receiveBuf[j]);
						}
 						 
						else {
							rxFlag=1;
							tmpBuffer[tmpPtr++] = 0;
							printf("BUF: %s\n",tmpBuffer);
							tmpPtr = 0;
				    		//TimeString(milliseconds); 
						    }
					    }
					SetCtrlVal(clientHandle,PANEL_TCP_RECEIVE,tmpBuffer);
					}
 				break;
        case TCP_DISCONNECT:
            MessagePopup ("TCP Client", "Server has closed connection!");
            SetCtrlVal (clientHandle, PANEL_TCP_CONNECTED, 0);
            g_connected = 0;
          //  MainPanelCB (0, EVENT_CLOSE, 0, 0, 0);
            break;
    }
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Respond to the UI and clear the receive screen for the user.              */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ClearScreenCB (int panel, int control, int event,
                               void *callbackData, int eventData1,
                               int eventData2)
{
    if (event == EVENT_COMMIT)
        ResetTextBox (panel, PANEL_TCP_RECEIVE, "");
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Respond to the panel closure to quit the UI loop.                         */
/*---------------------------------------------------------------------------*/
int CVICALLBACK MainPanelCB (int panel, int event, void *callbackData,
                             int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
        QuitUserInterface (0);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Report TCP Errors if any                                                  */
/*---------------------------------------------------------------------------*/
static void ReportTCPError(void)
{
    if (g_TCPError < 0)
        {
        char    messageBuffer[1024];
        sprintf(messageBuffer, 
            "TCP library error message: %s\nSystem error message: %s", 
            GetTCPErrorString (g_TCPError), GetTCPSystemErrorString());
        MessagePopup ("Error", messageBuffer);
        g_TCPError = 0;
        }
}


int ClientWrite(char *msg)
{
	int status;
	int n=0;
	int state;
    char buffer[12800];
	int bytesToRead;
	int bytesRead;
	int i;
	
	if (g_connected==0) return 0;
	
	//----enapsulate message with brackets------------
	
   status = ClientTCPWrite (g_hconversation, msg, strlen(msg), 5000);

   //bytesToRead = messageSize;
	bytesRead = 0;
	
	state = 0;
	if (SCPI) {

	while ((state !=2 ) && (bytesRead >= 0))
	{
		bytesRead = -8;
		bytesRead = ClientTCPRead (g_hconversation, &buffer[n], 1, 0);

		switch (state) {
			case 0:
					if (buffer[n]=='#')  state = 1;
					break;
			case 1: 
				 	if (buffer[n]==';') {
						state = 2;
						buffer[n] = 0;
					}
					else if (buffer[n]>= 0x20) 
						n+=bytesRead; 
					break;
		}

	  }
	for (i=0; i < 0x100000; i++);
		
	}
	else {
	while ((state !=2 ) && (bytesRead >= 0))
	{
		bytesRead = -8;
		bytesRead = ClientTCPRead (g_hconversation, &buffer[n], 1, 0);

		switch (state) {
			case 0:
					if (buffer[n]=='<')  state = 1;
					break;
			case 1: 
				 	if (buffer[n]=='>') {
						state = 2;
						buffer[n] = 0;
					}
					else if (buffer[n]>= 0x20) 
						n+=bytesRead; 
					break;
		}

	  }
	}
   return status;
}

int ClientParWrite(char *msg)
{
	int status;
	int n=0;
	int state;
    char buffer[12800];
	int bytesToRead;
	int bytesRead;
	
	if (g_connected==0) return 0;
	
	//----enapsulate message with brackets------------
	
   status = ClientTCPWrite (g_hconversation, msg, strlen(msg), 5000);

   //bytesToRead = messageSize;
	bytesRead = 0;
	
   return status;
}
int ClientRegRead(char *msg,char *buffer)
{


	int status;
	int messageSize=10;
	int bytesToRead;
	int bytesRead;
	int n=0;
	int state;

	if (g_connected==0) return 0;

	bytesToRead = messageSize;

	
	status = ClientTCPWrite (g_hconversation, msg, strlen(msg), 5000);

	//printf("%s",msg);
   
	bytesToRead = messageSize;
	bytesRead = 0;
	
	state = 0;
	if (SCPI) {
		while ((state !=2 ) && (bytesRead >= 0))
		{
			bytesRead = -8;
			bytesRead = ClientTCPRead (g_hconversation, &buffer[n], 1, 0);

			switch (state) {
				case 0:
						if (buffer[n]=='#')  state = 1;
						break;
				case 1: 
					 	if (buffer[n]==';') {
							state = 2;
							buffer[n] = 0;
							//sscanf(buffer,"REGGET:%s",buffer);
						}
						else if (buffer[n]>= 0x20) 
							n+=bytesRead; 
						break;
			}

		}
	}
	else {
		while ((state !=2 ) && (bytesRead >= 0))
		{
			bytesRead = -8;
			bytesRead = ClientTCPRead (g_hconversation, &buffer[n], 1, 0);

			switch (state) {
				case 0:
						if (buffer[n]=='<')  state = 1;
						break;
				case 1: 
					 	if (buffer[n]=='>') {
							state = 2;
							buffer[n] = 0;
						}
						else if (buffer[n]>= 0x20) 
							n+=bytesRead; 
						break;
			}

		}
	}
   return n;
}


/*

int ClientRegRead(char *msg,char *buffer)
{
	int status;
	int messageSize=10;
	int bytesToRead;
	int bytesRead;
	int n=0;
	int state = 0;

bytesToRead = messageSize;

	
status = ClientTCPWrite (g_hconversation, msg, strlen(msg), 5000);


   
bytesToRead = messageSize;

while (bytesToRead > 0)
{
bytesRead = ClientTCPRead (g_hconversation, &buffer[messageSize - bytesToRead], bytesToRead, 100);
bytesToRead -= bytesRead;
}

   return n;
}
*/


int CVICALLBACK CB_TEST_TCP (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		   ClientWrite("r 1");
			break;
	}
	return 0;
}

int CVICALLBACK CB_ONLINE_TCP (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int val;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_TCP,&val);
			if (val)  {
				netInterface = 2;
			    startClient();  
				SetCtrlVal(mainHandle,PANEL_MAIN_ONLINE_BUTTON,0);
			}
			else {
				netInterface = 0;
				closeClient();
			}
			break;
	}
	return 0;
}

