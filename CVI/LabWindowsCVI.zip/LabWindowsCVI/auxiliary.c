

/*

int CVICALLBACK CB_READ_BUF_SINGLE (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{  unsigned reg_addr,reg_data1,reg_data2,ndwords,reg_order;
   int re,im;
   int mag[16384];
   int i;
   FILE *fp;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_READ_REG_ADDR,&reg_addr);
			readBuffer(reg_addr,&reg_data1);   
			SetCtrlVal(comHandle,PANEL_COM_READ_REG_DATA,reg_data1);
			readBuffer(reg_addr+1,&reg_data1);
			SetCtrlVal(comHandle,PANEL_COM_READ_REG_DATA_2,reg_data1);
			break;
	}
	return 0;
}


int CVICALLBACK CB_READ_BUF (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{  unsigned reg_addr,reg_data1,reg_data2,ndwords,reg_order;
   unsigned checksum1=0,checksum2=0;
   int re,im;
   int mag[16384];
   int i;
   FILE *fp;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_READ_REG_ADDR,&reg_addr);
			GetCtrlVal(comHandle,PANEL_COM_NDWORDS,&ndwords);
			GetCtrlVal(comHandle,PANEL_COM_REG_ORDER,&reg_order);
			fp = fopen("fftbuffer.txt","w");
			for (i=0; i < ndwords; i+=2) {
			   if(reg_order){
			     readBuffer(reg_addr+i,&reg_data2);   
			     readBuffer(reg_addr+i+1,&reg_data1);
			   }
			   else {
			     readBuffer(reg_addr+i,&reg_data1);   
			     readBuffer(reg_addr+i+1,&reg_data2);
			   }
			   re = reg_data1 & 0xFFFF;
			   if (re > 32768) re -= 65536;
			   im = (reg_data1 >> 16) & 0xFFFF;
			   if (im > 32768) im -= 65536;
			   mag[i/2] = (int)sqrt(re*re+im*im);

			   re = reg_data2 & 0xFFFF;
			   if (re > 32768) re -= 65536;
			   im = (reg_data2 >> 16) & 0xFFFF;
			   if (im > 32768) im -= 65536;
			   mag[i/2+ndwords/2] = (int)sqrt(re*re+im*im);
			   
			   fprintf(fp,"%05d  %08X  -  %08X     %5d %5d  %5d\n",i/2,reg_data1,reg_data2,re,im,mag[i/2]);
			}
			SetCtrlVal(comHandle,PANEL_COM_READ_REG_DATA,reg_data1);
			fclose(fp);
		    YGraphPopup ("FFT Buffer", mag, ndwords, VAL_INTEGER);
			break;
	}
	return 0;
}

int CVICALLBACK CB_READ_BUF16 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{  unsigned reg_addr,reg_data1,reg_data2,ndwords,reg_order,export;
   unsigned reg_data[16384];
   int re,im;
   int mag[16384];
   int i,k;
   double real[16384],imag[16384];
   double xarray_real[2048],xarray_imag[2048];
   FILE *fp,*fpa,*fpb;
   unsigned checksum1=0,checksum2=0;

   switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(comHandle,PANEL_COM_BUFFER_BASE,&reg_addr);
			GetCtrlVal(comHandle,PANEL_COM_NDWORDS,&ndwords);
			GetCtrlVal(comHandle,PANEL_COM_REG_ORDER,&reg_order);
			GetCtrlVal(comHandle,PANEL_COM_EXPORT_FFTBUFFER,&export);

			if (export){
				fp  = fopen("fftbuffer16.txt","w");
				fpa = fopen("fftbuffer16a.txt","w");
				fpb = fopen("fftbuffer16b.txt","w");
			}
			for (i=0; i < ndwords; i+=16) {
				
			   readBuffer16(reg_addr+i,&reg_data[i]);   
			}
			
			for (i=0; i < ndwords; i+=2) {
				
				   checksum1 += reg_data[i];
				   checksum2 += reg_data[i+1];
				   re = reg_data[i] & 0xFFFF;
				   if (re >= 32768) re -= 65536;
				   im = (reg_data[i] >> 16) & 0xFFFF;
				   if (im >= 32768) im -= 65536;
				   mag[i/2] = (int)sqrt(re*re+im*im);
				   //mag[i/2] = re;
				   real[i/2] = (double) re;
				   imag[i/2] = (double) im;

				   if (export)
					   fprintf(fpa,"%05d  %8d %8d ",i,re,im);
				   if (export)
					   fprintf(fpb,"%05d  %8d %8d %8.0f",i,re,im,180/3.1415*atan2(im,re));

				   re = reg_data[i+1] & 0xFFFF;
				   if (re >= 32768) re -= 65536;
				   im = (reg_data[i+1] >> 16) & 0xFFFF;
				   if (im >= 32768) im -= 65536;
				   mag[i/2+ndwords/2] = (int)sqrt(re*re+im*im);
				  // mag[i/2+ndwords/2] = re;
				   real[i/2+ndwords/2] = (double) re;
				   imag[i/2+ndwords/2] = (double) im;
			
				   if (export) {
					   fprintf(fp,"%05d  %08X  -  %08X   %5d  %5d \n",i,reg_data[i+1],reg_data[i],mag[i/2],mag[i/2+ndwords/2] );
					   fprintf(fpa," %8d %8d\n",re,im);   
					   fprintf(fpb," %8d %8d %8.0f\n",re,im,180/3.1415*atan2(im,re));   
					   printf("%8d  of %d\r",i,ndwords);
				   }
			}
			 
			if (export) {
				fclose(fp);
				fclose(fpa);
				fclose(fpb);
			}
			printf("checksum1 = %08X  checksum2 = %08X\n",checksum1,checksum2);
		     YGraphPopup ("FFT Buffer", mag, ndwords, VAL_INTEGER);
			 for (i=0; i < 1024; i++)  {
				 xarray_real[i] = real[i];
				 xarray_real[(2048-i)%2048] = real[i];
				 xarray_imag[i] = imag[i];
				 xarray_imag[(2048-i)%2048] = -imag[i];
			 }
			 xarray_real[1024] = 0.0;
			 xarray_imag[1024] = 0.0;
			  InvFFT (xarray_real, xarray_imag, 2048);
		     YGraphPopup ("FFT Buffer", xarray_real, 2048, VAL_DOUBLE);
			break;
	}
	return 0;
}


*/

/*
void readBuffer(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   if (online == 0) {
	   *data = 0;
	   return;
   }
   FlushInQ (comport);
   sprintf(str,"gfft %d\r\n",addr);
   writeCmdString(str); 
   readByte(&tmp1);
   readByte(&tmp2);
   readByte(&tmp3);
   readByte(&tmp4);
   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
}

void readBuffer16(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   int i;
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   if (online == 0) {
	   *data = 0;
	   return;
   }
   FlushInQ (comport);
   sprintf(str,"bfft %d\r\n",addr);
   writeCmdString(str); 
   for (i=0; i < 16; i++) {
	   readByte(&tmp1);
	   readByte(&tmp2);
	   readByte(&tmp3);
	   readByte(&tmp4);
	   *(data+i) = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
   }
}
*/
// -- write ASCII-coded byte value --------------------
/*
void writeCmd(int addr, int data)
{  
   unsigned bytes_written;
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMW %04X %04X\n",addr,data);
   if (online == 0) return;
   bytes_written = ComWrtByte (comport, 'w');
   bytes_written = ComWrtByte (comport, ' ');
   writeByte((addr >>24) & 0xFF);
   writeByte((addr >>16) & 0xFF);
   writeByte((addr >> 8) & 0xFF);
   writeByte((addr ) & 0xFF);
   bytes_written = ComWrtByte (comport, ' ');
   writeByte((data >>24) & 0xFF);
   writeByte((data >>16) & 0xFF);
   writeByte((data >> 8) & 0xFF);
   writeByte((data ) & 0xFF);
   bytes_written = ComWrtByte (comport, 0x0D);
   bytes_written = ComWrtByte (comport, 0x0A);
}
*/
void readCmd(int addr, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   char str[32];
   
   if (fplog != NULL)
	   fprintf(fplog,"MEMR %02X\n",addr);
   if (online == 0) {
	   *data = 0;
	   return;
   }
   FlushInQ (comport);
   sprintf(str,"r %d\r\n",addr);
   writeCmdString(str); 
   readByte(&tmp1);
   readByte(&tmp2);
   readByte(&tmp3);
   readByte(&tmp4);
   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
}


void readString(int length, char *response)
{  
   unsigned bytes_written;
   int tmp;
   int i, queue_length;
   
   if (online == 0) {
	   *response = 0;
	   return;
   }
   do {
   queue_length = GetInQLen (comport);
   } while (queue_length < length);
   
   for (i=0; i < length; i++)
      response[i] = ComRdByte (comport);
   response[i] = 0;
}



void queryValue(char *str, int *data)
{  
   unsigned bytes_written;
   int tmp1,tmp2,tmp3,tmp4;
   
   if (online == 0) {
	   *data = 0;
	   return;
   }
   writeCmdString(str);
   FlushInQ (comport);
   readByte(&tmp1);
   readByte(&tmp2);
   readByte(&tmp3);
   readByte(&tmp4);
   *data = (tmp1<<24)+(tmp2<<16) +(tmp3<<8)+tmp4;
}




void GetStatus(void)
{
    unsigned reg_data;
    
	readCmd(0x00,&reg_data);
}


