/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL_AUD                        1
#define  PANEL_AUD_RADIOBUTTON_MONO       2       /* control type: radioButton, callback function: CB_AUDIO */
#define  PANEL_AUD_RADIOBUTTON_MUTE_R     3       /* control type: radioButton, callback function: CB_AUDIO */
#define  PANEL_AUD_RADIOBUTTON_MUTE_L     4       /* control type: radioButton, callback function: CB_AUDIO */
#define  PANEL_AUD_QUANTIZATION           5       /* control type: scale, callback function: CB_AUDIO */
#define  PANEL_AUD_VOLUMNE                6       /* control type: scale, callback function: CB_AUDIO */
#define  PANEL_AUD_FILTER                 7       /* control type: slide, callback function: CB_AUDIO */

#define  PANEL_COM                        2
#define  PANEL_COM_BAUDRATE               2       /* control type: ring, callback function: (none) */
#define  PANEL_COM_COM                    3       /* control type: ring, callback function: CB_COM_CFG */
#define  PANEL_COM_DECORATION_4           4       /* control type: deco, callback function: (none) */
#define  PANEL_COM_WRITE_REGN             5       /* control type: command, callback function: CB_WRITE_REGN */
#define  PANEL_COM_WRITE_REG_DATAN        6       /* control type: numeric, callback function: (none) */
#define  PANEL_COM_WRITE_REG_ADDRN        7       /* control type: numeric, callback function: (none) */
#define  PANEL_COM_WRITE_REG              8       /* control type: command, callback function: CB_WRITE_REG */
#define  PANEL_COM_WRITE_REG_DATA         9       /* control type: numeric, callback function: (none) */
#define  PANEL_COM_WRITE_REG_ADDR         10      /* control type: numeric, callback function: (none) */
#define  PANEL_COM_READ_BUF               11      /* control type: command, callback function: CB_READ_BUF */
#define  PANEL_COM_READ_REG               12      /* control type: command, callback function: CB_READ_REG */
#define  PANEL_COM_READ_REG_DATA_2        13      /* control type: numeric, callback function: (none) */
#define  PANEL_COM_READ_REG_DATA          14      /* control type: numeric, callback function: (none) */
#define  PANEL_COM_READ_REG_ADDR          15      /* control type: numeric, callback function: (none) */
#define  PANEL_COM_TEXTMSG_7              16      /* control type: textMsg, callback function: (none) */
#define  PANEL_COM_REGISTER_BASE          17      /* control type: textButton, callback function: (none) */
#define  PANEL_COM_COM_STRING             18      /* control type: ring, callback function: (none) */
#define  PANEL_COM_TEXTMSG                19      /* control type: textMsg, callback function: (none) */
#define  PANEL_COM_TEXTMSG_8              20      /* control type: textMsg, callback function: (none) */
#define  PANEL_COM_TEXTMSG_9              21      /* control type: textMsg, callback function: (none) */

#define  PANEL_MAIN                       3
#define  PANEL_MAIN_DECORATION_5          2       /* control type: deco, callback function: (none) */
#define  PANEL_MAIN_EXIT                  3       /* control type: command, callback function: CB_EXIT */
#define  PANEL_MAIN_CANVAS                4       /* control type: canvas, callback function: (none) */
#define  PANEL_MAIN_ONLINE_BUTTON         5       /* control type: textButton, callback function: CB_ONLINE */
#define  PANEL_MAIN_HW_SERIALNUM          6       /* control type: numeric, callback function: (none) */
#define  PANEL_MAIN_HW_VERSION            7       /* control type: numeric, callback function: (none) */
#define  PANEL_MAIN_SW_VERSION            8       /* control type: numeric, callback function: (none) */
#define  PANEL_MAIN_TIMESTAMP1            9       /* control type: string, callback function: (none) */
#define  PANEL_MAIN_PICTURE               10      /* control type: picture, callback function: (none) */
#define  PANEL_MAIN_TIMER                 11      /* control type: timer, callback function: CB_TIMER */
#define  PANEL_MAIN_INTERR                12      /* control type: numeric, callback function: (none) */
#define  PANEL_MAIN_INTCOUNTER            13      /* control type: numeric, callback function: (none) */
#define  PANEL_MAIN_COM_DEBUG             14      /* control type: textButton, callback function: (none) */

#define  PANEL_SER                        4
#define  PANEL_SER_TESTWAV                2       /* control type: command, callback function: CB_TESTWAV */
#define  PANEL_SER_SERIAL_PULSELEN        3       /* control type: numeric, callback function: CB_SERIAL_SETUP */
#define  PANEL_SER_SERIAL_BITRATE         4       /* control type: numeric, callback function: CB_SERIAL_SETUP */
#define  PANEL_SER_WAVESELECT             5       /* control type: slide, callback function: CB_SERIAL_SETUP */

#define  PANEL_TX                         5
#define  PANEL_TX_SLIDERS                 2       /* control type: numeric, callback function: (none) */
#define  PANEL_TX_RADIOBUTTON_LED3        3       /* control type: radioButton, callback function: CB_LEDS */
#define  PANEL_TX_RADIOBUTTON_LED2        4       /* control type: radioButton, callback function: CB_LEDS */
#define  PANEL_TX_RADIOBUTTON_LED0        5       /* control type: radioButton, callback function: CB_LEDS */
#define  PANEL_TX_RADIOBUTTON_LED1        6       /* control type: radioButton, callback function: CB_LEDS */
#define  PANEL_TX_BB_OFFSET               7       /* control type: scale, callback function: CB_SETUP_TX */
#define  PANEL_TX_RF_FREQUENCY            8       /* control type: scale, callback function: CB_SETUP_TX */
#define  PANEL_TX_BB_FREQUENCY            9       /* control type: scale, callback function: CB_SETUP_TX */
#define  PANEL_TX_RF_LEVEL                10      /* control type: scale, callback function: CB_SETUP_TX */
#define  PANEL_TX_BB_LEVEL                11      /* control type: scale, callback function: CB_SETUP_TX */
#define  PANEL_TX_BB_WAVSEL               12      /* control type: ring, callback function: CB_SETUP_TX */
#define  PANEL_TX_RADIOBUTTON_FM          13      /* control type: radioButton, callback function: CB_SET_FM */
#define  PANEL_TX_RADIOBUTTON_AM          14      /* control type: radioButton, callback function: CB_SET_AM */
#define  PANEL_TX_RADIOBUTTON_CW          15      /* control type: radioButton, callback function: CB_SET_CW */
#define  PANEL_TX_RF_INC                  16      /* control type: numeric, callback function: (none) */
#define  PANEL_TX_F_DEC                   17      /* control type: command, callback function: CB_FDEC */
#define  PANEL_TX_F_INC                   18      /* control type: command, callback function: CB_FINC */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK CB_AUDIO(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_COM_CFG(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_EXIT(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_FDEC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_FINC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_LEDS(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_ONLINE(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_READ_BUF(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_READ_REG(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_SERIAL_SETUP(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_SET_AM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_SET_CW(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_SET_FM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_SETUP_TX(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_TESTWAV(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_TIMER(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_WRITE_REG(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CB_WRITE_REGN(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
