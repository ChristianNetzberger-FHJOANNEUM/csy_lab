/*----------------------------------------------------------------------------*/
/* Infinite Impulse Response (IIR) Filter                                     */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example illustrates the design of an Infinite Impulse Response (IIR)\n\
Filter. In this example, we use the Cascade Coefficient technique for\n\
designing filters rather than the simple one step method.  This method is\n\
more stable than the traditional one step method.  We recommend that you use\n\
this method for designing IIR filters."

/*----------------------------------------------------------------------------*/
/* Include                                                                    */
/*----------------------------------------------------------------------------*/
#include <ansi_c.h>
#include <cvirte.h>     /* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>
#include <analysis.h>
#include "fpga_control.h"
#include "globals.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;
static int autoRun = 1;

extern int iirHandle;

static IIRFilterPtr filter_information;

/*----------------------------------------------------------------------------*/
/* Prototypes                                                                 */
/*----------------------------------------------------------------------------*/
int DoIIRFilter(void);
void Show_IIR(void);

extern void WriteRegister(unsigned addr, unsigned data);

/*----------------------------------------------------------------------------*/
/* DoIIRFilter                                                                */
/*----------------------------------------------------------------------------*/
int DoIIRFilter(void)
{
    static int filter_design;
    static int filter_type;
    static double ripple;
    static double attentuation;
    static int filter_order;
    static int display_type;
    static double sampling_rate;
    static double upper_cutoff_frequency;
    static double lower_cutoff_frequency;
    static int i;
    static int err;
    double *input_signal;
    double *filtered_signal;
    double *filtered_signal_im;
    double *x_array;
    double *y_array;
    
    GetCtrlVal(iirHandle, PANEL_IIR_Design, &filter_design);
    GetCtrlVal(iirHandle, PANEL_IIR_Type, &filter_type);
    GetCtrlVal(iirHandle, PANEL_IIR_Ripple, &ripple);
    GetCtrlVal(iirHandle, PANEL_IIR_Attentuation, &attentuation);
    GetCtrlVal(iirHandle, PANEL_IIR_Order, &filter_order);
    GetCtrlVal(iirHandle, PANEL_IIR_SamplingRate, &sampling_rate);
    GetCtrlVal(iirHandle, PANEL_IIR_HCF, &upper_cutoff_frequency);
    GetCtrlVal(iirHandle, PANEL_IIR_LCF, &lower_cutoff_frequency);
    GetCtrlVal(iirHandle, PANEL_IIR_Display, &display_type);
    
    switch(filter_type)
    {
        case 0 : /* LowPass Filter */
        filter_information = AllocIIRFilterPtr (LOWPASS, filter_order);
        break;
            
        case 1: /* HighPass Filter */
        filter_information = AllocIIRFilterPtr (HIGHPASS, filter_order);    
        break;
            
        case 2: /* BandPass Filter */
        filter_information = AllocIIRFilterPtr (BANDPASS, filter_order);    
        break;
            
        case 3: /* BandStop Filter */
        filter_information = AllocIIRFilterPtr (BANDSTOP, filter_order);    
        break;
    }
    
    switch(filter_design)
    {
        case 0 : /* Butterworth Filter */
        err = Bw_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                              upper_cutoff_frequency, filter_information);
        break;
        
        case 1: /* Chebyshev Filter */
        err = Ch_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                              upper_cutoff_frequency, ripple,
                              filter_information);
        break;
        
        case 2: /* Inverse Chebyshev Filters */
        err = InvCh_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                                 upper_cutoff_frequency, attentuation,
                                 filter_information);
        break;
        
        case 3: /* Elliptic Filter */
        err = Elp_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                               upper_cutoff_frequency, ripple, attentuation,
                               filter_information);
        break;
        
        case 4: /* Bessel Filter */
        err = Bessel_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                                  upper_cutoff_frequency, filter_information);
        break;
    }
	Show_IIR();
    input_signal = (double *)malloc(1024*sizeof(double));
    if(input_signal == NULL)
    {
        FreeIIRFilterPtr(filter_information);
        return OutOfMemAnlysErr;
    }
    err = Impulse (1024, 1.0, 0, input_signal);
    if(err != NoAnlysErr)
    {
        FreeIIRFilterPtr(filter_information);
        free(input_signal);
        return err;
    }
    filtered_signal = (double *)malloc(1024*sizeof(double));
    if(filtered_signal == NULL)
    {
        FreeIIRFilterPtr(filter_information);
        free(input_signal);
        return OutOfMemAnlysErr;
    }
    
    filtered_signal_im = (double *)malloc(1024*sizeof(double));
    if(filtered_signal_im == NULL)
    {
        FreeIIRFilterPtr(filter_information);
        free(input_signal);
        free(filtered_signal);
        return OutOfMemAnlysErr;
    }
    err = IIRCascadeFiltering (input_signal, 1024, filter_information,
                               filtered_signal);
    FreeIIRFilterPtr(filter_information);
    
    if(err != NoAnlysErr)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
    }
    /* ReFFT function returns the real part of the FFT in the input array filtered_signal */
    /* and the imaginary part of the FFT in the array filtered_signal_im */

    err = ReFFT (filtered_signal, filtered_signal_im, 1024);
    if(err != NoAnlysErr)
    {   
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
    }
    
    x_array = (double *)malloc(512*sizeof(double));
    if(x_array == NULL)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        return OutOfMemAnlysErr;
    }
    
    y_array = (double *)malloc(512*sizeof(double));
    if(x_array == NULL)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        free(x_array);
        return OutOfMemAnlysErr;
    }
    
    for(i = 0; i < 512; i++) *(x_array+i) = i * (sampling_rate/1024.0);
    if(display_type == 1)
    {
        for(i = 0; i < 512; i++) *(y_array+i) = 
            20.0*log10(sqrt((*(filtered_signal+i)**(filtered_signal+i))+(*(filtered_signal_im+i)**(filtered_signal_im+i))));
    }
    else
    {
        for(i = 0; i < 512; i++) *(y_array+i) = 
                                                                                                               
            sqrt((*(filtered_signal+i)**(filtered_signal+i))+(*(filtered_signal_im+i)**(filtered_signal_im+i)));
    }
    DeleteGraphPlot (iirHandle, PANEL_IIR_GRAPH1, -1, VAL_DELAYED_DRAW);
    PlotXY (iirHandle, PANEL_IIR_GRAPH1, x_array, y_array, 512,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_RED);
    
    for(i = 0; i < 512; i++) *(filtered_signal_im+i) = atan2(*(filtered_signal_im+i),*(filtered_signal+i));
    err = UnWrap1D (filtered_signal_im, 512);
    if(err != NoAnlysErr)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        free(x_array);
        free(y_array);
    }
    DeleteGraphPlot (iirHandle, PANEL_IIR_GRAPH2, -1, VAL_DELAYED_DRAW);
    PlotXY (iirHandle, PANEL_IIR_GRAPH2, x_array, filtered_signal_im, 512,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_RED);
    free(input_signal);
    free(filtered_signal);
    free(filtered_signal_im);
    free(x_array);
    free(y_array);

    return 0;

}  

void Show_IIR(void)
{
	double a_coeff[16],b_coeff[16];
	int i;
	
	for (i=0; i < 10; i++) {
		a_coeff[i]=0.0;
		b_coeff[i]=0.0;
	}
		
	
	CascadeToDirectCoef (filter_information, a_coeff, 10, b_coeff, 10);
//	printf("filter coeff a[] = ");
	for (i=0; i < 10; i++) {
	  SetTableCellAttribute (iirHandle,PANEL_IIR_TABLE_IIR, MakePoint (2, i+2),ATTR_CTRL_VAL, a_coeff[i]);
	  SetTableCellAttribute (iirHandle,PANEL_IIR_TABLE_IIR, MakePoint (3, i+2),ATTR_CTRL_VAL, b_coeff[i]);
	}
	
	/*
	   printf("%1.5f ",a_coeff[i]);
	printf("\n");
	
	printf("filter coeff b[] = ");
	for (i=0; i < 10; i++)
	   printf("%1.5f ",b_coeff[i]);
	printf("\n");
	*/
}  

void Load_IIR(void)
{
	double a_coeff[16],b_coeff[16];
	int i;
	int reg1,reg2;
	double w0,w1;
	double sig_in = 1.0;
	double y[1024];

	unsigned BASE_IIR =0x800;
	unsigned reg_addr = BASE_IIR + 0x100;
		
	for (i=0; i < 10; i++) {
		a_coeff[i]=0.0;
		b_coeff[i]=0.0;
	}
		
	
	CascadeToDirectCoef (filter_information, a_coeff, 10, b_coeff, 10);
	
	
	//printf("filter coeff a[] = ");
	for (i=0; i < 10; i++) {
	    GetTableCellAttribute (iirHandle,PANEL_IIR_TABLE_IIR, MakePoint (2, i+2),ATTR_CTRL_VAL, &a_coeff[i]);
	    GetTableCellAttribute (iirHandle,PANEL_IIR_TABLE_IIR, MakePoint (3, i+2),ATTR_CTRL_VAL, &b_coeff[i]);
	    reg1 = (int)(a_coeff[i]*4096.0*65536.0);
	    reg2 = (int)(b_coeff[i]*32768.0*65536.0);
		WriteRegister(reg_addr+2*i,  reg1);
		WriteRegister(reg_addr+2*i+1,reg2);
	}
	
	w0=0; w1=0;
	for (i=0; i < 100; i++) {
		if ((i % 20) < 10) sig_in = 1.0; else sig_in = -1.0;
		w1 = w0;
		w0 = sig_in - a_coeff[1]*w1;
		y[i]  = w0*b_coeff[0]+w1*b_coeff[1];
		printf("%d   %f %f  %f\n",i,w0,w1,y[i]);
		
	}
	YGraphPopup ("filter", y, 50, VAL_DOUBLE);
	
	
	/*
	   printf("%1.5f ",a_coeff[i]);
	printf("\n");
	
	printf("filter coeff b[] = ");
	for (i=0; i < 10; i++)
	   printf("%1.5f ",b_coeff[i]);
	printf("\n");
	*/
}  


/*----------------------------------------------------------------------------*/
/* RunProgram                                                                 */
/*----------------------------------------------------------------------------*/
int CVICALLBACK RunProgram (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            if ((autoRun) || (control == PANEL_IIR_RUN))
                DoIIRFilter();
            
            break;
    }
    return 0;
}



int CVICALLBACK AutoChange (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event)
        {
        case EVENT_COMMIT:
            GetCtrlVal(panel, control, &autoRun);
            break;
        }
    return 0;
}

int CVICALLBACK CB_SHOW_IIRSTAT (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Show_IIR();
			break;
	}
	return 0;
}

int CVICALLBACK CB_LOAD_COEFF (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Load_IIR();
			break;
	}
	return 0;
}
